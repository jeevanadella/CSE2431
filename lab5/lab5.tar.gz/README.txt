Name: Sreenivas Jeevan Nadella

Course: CSE 2431

Date: 11/15/2024

Instructions to Compile: 
1. run the command: make all

Instructions to Run:
1. run the command: ./mysh

Instructions to Exit Shell:
1. run the commend: exit