Name: Sreenivas Jeevan Nadella

Course: CSE 2431

Date: 08/30/2024

Instructions to Compile: 
1. run the command: make all

Instructions to Run:
1. run the command: ./mysh