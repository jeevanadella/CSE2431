Name: Sreenivas Jeevan Nadella

Course: CSE 2431

Date: 08/22/2024

Instructions: Run make in the lab0 directory.
