Name: Sreenivas Jeevan Nadella

Course: CSE 2431

Date: 09/16/2024

Instructions to Compile: 
1. run the command: make all

Instructions to Run:
1. run the command (replacing command line arguments as instructed in lab description): ./bounded_buffer <sleep_time> <number_producers> <number consumers>
